package com.streamC3S.commonTools;

import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.RecursiveTask;

/**
 * @className ConcurrentComputeSimilarityByClass
 * @author YunlongMi
 * @details Concurrent Compute Similarity By Class
 * @date Jan. 15, 2020
 * @version V1.1
 * @since jdk1.8
 */
public class ConComSimilarityByClass extends RecursiveTask<Double> {
	private static final long serialVersionUID = -8563054757788675804L;
	private static final int MAX = 10;
	private Object[] obj;
	private double[] ins;
	private int beginNum, endNum;

	public ConComSimilarityByClass(Object[] obj, double[] ins, int beginNum, int endNum) {
		this.obj = obj;
		this.ins = ins;// a instance
		this.beginNum = beginNum;
		this.endNum = endNum;
	}

	@SuppressWarnings("unchecked")
	@Override
	protected Double compute() {
		if ((endNum - beginNum) <= MAX) {// 每类一个线程运行
			double maxTheta = Integer.MIN_VALUE;
			for (int index = beginNum; index <= endNum; ++index) {
				double[] cIntent = ((Entry<double[], Set<Integer>>) obj[index]).getKey();// 内涵
				double theta = 1 - getSimilarity(ins, cIntent); // 计算概念间相似度
				if (theta >= maxTheta) {
					maxTheta = theta;
				} // end_of_if
			}
			return maxTheta;
		} else {
			int middle = (beginNum + endNum) / 2;
			ConComSimilarityByClass left = new ConComSimilarityByClass(obj, ins, beginNum, middle);
			ConComSimilarityByClass right = new ConComSimilarityByClass(obj, ins, middle + 1, endNum);
			left.fork();
			right.fork();
			if (left.join() >= right.join()) {
				return left.join();
			} else {
				return right.join();
			}
		} // end_of_if_Max
	}// end_of_compute

	/**
	 * @param ins
	 * @param attributeSet
	 * @return 使用2范数，即欧式离
	 */
	private static double getSimilarity(double[] ins, double[] attributeSet) {
		double result = 0.0;
		for (int i = 0; i < attributeSet.length; ++i) {
			result += Math.pow(ins[i] - attributeSet[i], 2);
		} // end_of_for
		return Math.sqrt(result);
	}// end_of_getSimilarity
}// end_of_class
