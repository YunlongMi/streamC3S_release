package com.streamC3S.commonTools;

import java.util.Set;
import java.util.Vector;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.RecursiveTask;

import com.streamC3S.utils.MaxUtil;

/**
 * @className ConcurrentComputeSimilarityByIns
 * @author Dr. YunlongMi
 * @details Concurrent Compute Similarity By Instances
 * @date Jue. 4, 2020
 * @version V1.1
 * @since jdk1.8
 */
public class ConComSimilarityByIns extends RecursiveTask<Vector<Object>> {
	private static final long serialVersionUID = -8563054757788675804L;
	private static final int MAX = 10;
	private int beginNum, endNum;
	private ArrayList<Map<double[], Set<Integer>>> conceptPoolList;
	private double[][] bach_X;
	private int[] bach_Y;
	private int correct = 0;
	private int rowStart;

	public ConComSimilarityByIns(ArrayList<Map<double[], Set<Integer>>> conceptPoolList, double[][] bach_X,
			int[] bach_Y, int beginNum, int endNum, int rowStart) {
		this.conceptPoolList = conceptPoolList;// concept pools
		this.bach_X = bach_X;// new coming instances
		this.bach_Y = bach_Y;// label information
		this.beginNum = beginNum;
		this.endNum = endNum;
		this.rowStart = rowStart;
	}

	@SuppressWarnings("unchecked")
	@Override
	protected Vector<Object> compute() {
		if ((endNum - beginNum) <= MAX) {
			GetConceptSimilarity gcs = new GetConceptSimilarity();
			Vector<Object> tempVec = new Vector<Object>();
			double[] ctSimilaritytWeights = new double[conceptPoolList.size()];
			double[][] ctIntents = new double[conceptPoolList.size()][];
			List<double[]> errorIntentList = new ArrayList<double[]>();
			for (int index = beginNum; index < endNum; ++index) {
				/** Computes concept similarity */
				double[] ins = bach_X[index];// intent
				for (int type = 0; type < conceptPoolList.size(); ++type) {
					Vector<Object> vec = gcs.computeSimiarityWeithts(conceptPoolList, ins, type);
					ctSimilaritytWeights[type] = (double) vec.get(0);// get similarity
					ctIntents[type] = (double[]) vec.get(1);// get intent for different concepts
				} // end_of_for
				/**
				 * Gets the numbers of correct prediction and instance list (forming by
				 * prediction value rather than true label due to lack of label information)
				 */
				int pLabel = MaxUtil.getMDoubleIndex(ctSimilaritytWeights);// get prediction value (class label).
				if (pLabel == bach_Y[index]) {
					correct++;
				} else {
					/** It means that the concept should be removed from concept spaces */
					// errorIntentList.add(ins);// error instance from a test dataset
					errorIntentList.add(ctIntents[pLabel]);// error concept from existing concept space
				} // end_of_if
			} // end_of_for
			tempVec.add(correct);// add correct
			tempVec.add(errorIntentList);// add error concepts
			return tempVec;
		} else {
			int middle = (beginNum + endNum) / 2;
			ConComSimilarityByIns left = new ConComSimilarityByIns(conceptPoolList, bach_X, bach_Y, beginNum, middle,
					rowStart);
			ConComSimilarityByIns right = new ConComSimilarityByIns(conceptPoolList, bach_X, bach_Y, middle, endNum,
					rowStart);
			left.fork();
			right.fork();
			left.join();
			right.join();

			Vector<Object> tempVec = new Vector<Object>();
			int correct = (int) left.getRawResult().get(0) + (int) right.getRawResult().get(0);// correct
			List<double[]> lErrorIntentList = (List<double[]>) left.getRawResult().get(1);
			List<double[]> rErrorIntentList = (List<double[]>) right.getRawResult().get(1);
			lErrorIntentList.addAll(rErrorIntentList);// collect error concepts
			tempVec.add(correct);// add correct
			tempVec.add(lErrorIntentList); // add error concepts
			return tempVec;
		} // end_of_if
	}// end_of_compute
}// end_of_class_ConcurrentComputeSimilarityByIns
