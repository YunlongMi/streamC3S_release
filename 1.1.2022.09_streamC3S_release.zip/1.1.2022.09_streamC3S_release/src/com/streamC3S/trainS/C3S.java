package com.streamC3S.trainS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ExecutionException;

import com.streamC3S.evaluateS.UpdateAllLabC3S;
import com.streamC3S.evaluateS.UpdateAllLabC3S_E;
import com.streamC3S.evaluateS.UpdateStaticC3S;
import com.streamC3S.initialS.InitalMethod;
import com.streamC3S.utils.ParametersUtil;

/**
 * @author Dr. Yunlong Mi
 * @version V1.1
 * @date Jul. 3, 2020
 * @details streamC3S
 */
public class C3S {
	private Vector<Object> train_vec, grow_vec;
	private Vector<Object> resVec; // It is a global variable and input into evaluate method
	private ArrayList<Map<double[], Set<Integer>>> gConceptPoolList, tConceptPoolList;

	public C3S(Vector<Object> train_vec) {
		this.train_vec = train_vec;
	}// end_of_CCCS

	/**
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws ExecutionException
	 * @details Constructing concept spaces by means of selecting an theta.
	 */
	@SuppressWarnings("unchecked")
	public void initialS() throws IOException, InterruptedException, ExecutionException {
		InitalMethod IM = new InitalMethod(train_vec);// forms concept spaces based on a train dataset
		Vector<Object> vec = IM.initialConceptPoolByTheta();
		tConceptPoolList = (ArrayList<Map<double[], Set<Integer>>>) vec.get(0);// gets concept pool
		if (ParametersUtil.U == 1) {// for data stream without labeled information
			System.err.println(
					"This function will be developed in the next version (for U=1) ! Please set U=2 in ParametersUtil !");
			InitalMethod IMG = new InitalMethod(grow_vec);// forms concept spaces based on a grow dataset
			Vector<Object> vecG = IMG.initialConceptPoolByTheta();
			gConceptPoolList = (ArrayList<Map<double[], Set<Integer>>>) vecG.get(0);// gets concept pool
		} // end_of_if
	}// end_of_initialS

	/**
	 * @param epochs
	 * @return
	 * @throws ExecutionException
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public Vector<Object> trainS()
			throws IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		TrainC3S tC3S = new TrainC3S();
		switch (ParametersUtil.U) {
		case 0:// for static learning
		case 2:// for a labeled data stream
			tConceptPoolList = tC3S.trainingMethod(tConceptPoolList);
			break;
		case 1:// for a partially labeled data stream
			tConceptPoolList = tC3S.trainingMethod(tConceptPoolList);
			gConceptPoolList = tC3S.trainingMethod(gConceptPoolList);
			break;
		default:
			System.err.println("Please input the type of data stream (0, 1, 2) !");
		}// end_of_switch
		return resVec;
	}// end_of_train

	/**
	 * @param test_vec
	 * @throws ExecutionException
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @details Concept generalization
	 */
	public void evaluateS(Vector<Object> test_vec)
			throws InterruptedException, ExecutionException, ClassNotFoundException, IOException {
		int[] train_Y = (int[]) train_vec.get(1);// label information for training dataset
		train_vec.clear();
		switch (ParametersUtil.U) {
		case 0: // for static learning
			UpdateStaticC3S sC3S = new UpdateStaticC3S(tConceptPoolList, test_vec);
			sC3S.learningC3S();
			break;
		case 1:// for a partially labeled data stream
			System.err.println("This function will be developed in the next version !");
			break;
		case 2:// for a labeled data stream
			if (ParametersUtil.methodType.equals("streamC3S")) {
				UpdateAllLabC3S lC3S = new UpdateAllLabC3S(tConceptPoolList, test_vec, train_Y);
				lC3S.learningC3S();
				tConceptPoolList.clear();
				test_vec.clear();
			} else if (ParametersUtil.methodType.equals("streamC3S_E")) {
				UpdateAllLabC3S_E lC3S = new UpdateAllLabC3S_E(tConceptPoolList, test_vec, train_Y);
				lC3S.learningC3S();
				tConceptPoolList.clear();
				test_vec.clear();
			} else {
				System.err.println("Please input the method streamC3S or streamC3S_E ! ");
			} // end_of_if
			break;
		default:
			System.err.println("Please input the type of data stream (0, 1, 2)!");
		}// end_of_switch
	}// end_of_evaluate
}
