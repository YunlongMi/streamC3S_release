package com.streamC3S.evaluateS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;

import com.streamC3S.commonTools.ConComSimilarityByIns;
import com.streamC3S.commonTools.GetNewConcepts;
import com.streamC3S.commonTools.UpdateConceptSpace;
import com.streamC3S.utils.ParametersUtil;
import com.streamC3S.utils.WriteFileUtil;

/**
 * @Description: A data stream with label information.
 * @author Dr. Yunlong
 * @date Jun., 2 2020
 */
public class UpdateAllLabC3S {
	private ArrayList<Map<double[], Set<Integer>>> conceptPoolList;
	private List<double[]> errorIntentList;
	private Vector<Object> test_vec;
	private int[] train_Y;

	public UpdateAllLabC3S(ArrayList<Map<double[], Set<Integer>>> conceptPoolList, Vector<Object> test_vec,
			int[] train_Y) {
		this.conceptPoolList = conceptPoolList;
		this.test_vec = test_vec;
		this.train_Y = train_Y;
	}

	@SuppressWarnings("unchecked")
	public void learningC3S() throws InterruptedException, ExecutionException, ClassNotFoundException, IOException {
		/** Load information */
		UpdateConceptSpace ucs = new UpdateConceptSpace();// load updating concept space function
		GetNewConcepts gnc = new GetNewConcepts();// load the method of getting new concepts.
		int batchSize = ParametersUtil.C;// load batch size

		/** Initial varies */
		double[][] test_X = (double[][]) test_vec.get(0);// data information
		int[] test_Y = (int[]) test_vec.get(1);// label information
		HashMap<Integer, Integer> classMap = (HashMap<Integer, Integer>) test_vec.get(2);// class information
		int calssNumber = classMap.size();// class information
		int tempBatchsize = 0, epoch = 0;
		float corrSum = 0;
		List<HashMap<Integer, double[]>> instanceList = new ArrayList<HashMap<Integer, double[]>>();// <No,attribute>
		List<Map<double[], Set<Integer>>> conceptList = new ArrayList<Map<double[], Set<Integer>>>();// <intent,extent>
		for (int i = 0; i < calssNumber; ++i) {// initial instanceList
			instanceList.add(new HashMap<Integer, double[]>());// instances-<No,attribute>
		} // end_of_for

		/**
		 * For data stream: if C=1, forming a new concept and computing similarity;<br/>
		 * if C>1, forming new concepts and computing concept similarity in parallel.
		 */
		for (int rowN = 0; rowN < test_X.length; rowN++) {
			tempBatchsize++;
			instanceList.get(test_Y[rowN]).put(rowN + train_Y.length, test_X[rowN]);// get instances by class.
			/**
			 * (1) For batchSize=1, constructing new concepts one by one;<br/>
			 * (2) For batchSize > 1, it will constructing concepts in parallel.
			 */
			if (tempBatchsize == batchSize) {
				epoch++;// record the blocks.
				double[][] bach_X = new double[batchSize][];// an array for batch instances.
				int[] bach_Y = new int[batchSize];// an array for batch instances.
				int rowStart = rowN + train_Y.length - batchSize + 1;// the begin number of new batch size.
				/** src=test_X, srcPos, dest=bach_X, destPos=0, length=batchSize */
				System.arraycopy(test_X, epoch * batchSize - batchSize, bach_X, 0, batchSize);// for instances
				System.arraycopy(test_Y, epoch * batchSize - batchSize, bach_Y, 0, batchSize);// for label information

				ForkJoinPool forkJoinPool = new ForkJoinPool();
				Future<Vector<Object>> future = forkJoinPool
						.submit(new ConComSimilarityByIns(conceptPoolList, bach_X, bach_Y, 0, batchSize, rowStart));
				Vector<Object> vec = future.get();
				int correct = (int) vec.get(0);// get correct
				errorIntentList = (List<double[]>) vec.get(1);// get error concepts
				forkJoinPool.shutdown();

				/** Saves results by different batch size. */
				corrSum += (float) correct / batchSize;
				if (ParametersUtil.showResult.equals("bachSize")) {
					String fileName = "./data/Result[bachSize]_with_label.txt";
					WriteFileUtil outFile = new WriteFileUtil(fileName);
					outFile.fileWriterLine((float) correct / batchSize + ",");
					System.out.println(
							"epoch--" + epoch + "--accSum--" + corrSum + "--acc--" + (float) correct / batchSize);
				} // end_of_if (ParametersUtil.showResult.equals("bachSize"))
			} // end_of_if (tempBatchsize == batchSize)

			/**
			 * Constructs new concepts; and then adds new concepts into original concept
			 * pools by batchSize directly. (1) For batchSize=1, it will add new concepts
			 * into pool directly; (2) For batchSize>1, it will update pool with removing
			 * errorIntentList and completing concept fusion process.
			 */
			if (tempBatchsize == batchSize) {
				conceptList = gnc.getNewConcepts(instanceList);// get new concepts.
				ucs.updateConceptList(conceptPoolList, errorIntentList, conceptList);
				tempBatchsize = 0; // initial to 0.
				instanceList.clear();// clear instances.
				for (int i = 0; i < calssNumber; ++i) {// initial instanceList
					instanceList.add(new HashMap<Integer, double[]>());
				} // end_of_for
			} // end_of_if
		} // end_of_for

		/** 将其结果保存到文件中:[所有正确样本/总样本数] */
		// String fileName = "./data/Result.txt";
		// WriteFileUtil outFile = new WriteFileUtil(fileName);
		// outFile.fileWriter((float) correct / test_Y.length + ",");
		// System.out.println((float) correct / test_Y.length + ",");

		/** 将其结果保存到文件中:[所有块/总块数] */
		if (ParametersUtil.showResult.equals("overall")) {
			int chunk_num = test_Y.length / ParametersUtil.C;
			String fileName = "./data/Result[overall]_with_label.txt";
			WriteFileUtil outFile = new WriteFileUtil(fileName);
			outFile.fileWriter((float) corrSum / chunk_num + ",");
			System.out.println("overallAcc--"+(float) corrSum / chunk_num + "--chunkNum--" + chunk_num);
		} // end_of_if (ParametersUtil.showResult.equals("overall"))
	}
}
