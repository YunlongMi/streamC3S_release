package com.streamC3S.main;

import java.util.Vector;

import com.streamC3S.trainS.C3S;
import com.streamC3S.utils.LoadDataUtil;
import com.streamC3S.utils.ParametersUtil;

/**
 * @ClassName: RunMethod
 * @Description: Entry our method
 * @author Dr. Yunlong Mi
 * @date 2022/9/3
 * @version streamC3S_release[Version 1.1]: <br/>
 *          streamC3S (dynamic concept learning by concept-cognitive computing
 *          system) and streamC3S_E (add error corrects rate for concept drift
 *          detection). streamC3S是之前fastC3S改名而来<br/>
 * @since jdk1.8
 */
public class RunMethod {
	public static void main(String[] args) throws Exception {
		/** Loop 20 times */
		for (int index = 1; index <= 20; ++index) {
			/** Load datasets. */
			long s1 = System.currentTimeMillis();
			Vector<Object> grow_vec = LoadDataUtil
					.loadData(ParametersUtil.train_path.replace("indexNum", String.valueOf(index)));
			Vector<Object> test_vec = LoadDataUtil
					.loadData(ParametersUtil.test_path.replace("indexNum", String.valueOf(index)));

			long e1 = System.currentTimeMillis();
			System.err.println("Load dataset：" + (e1 - s1) + "(ms)");

			/** Instantiation system, 实例化系统 */
			C3S c3s = new C3S(grow_vec);
			/** Initial system, 系统初始化 */
			long s2 = System.currentTimeMillis();
			c3s.initialS();
			long e2 = System.currentTimeMillis();
			System.err.println("Initial system：" + (e2 - s2) + "(ms)");

			/** Learning for system, 系统学习 */
			long s3 = System.currentTimeMillis();
			c3s.trainS();
			long e3 = System.currentTimeMillis();
			System.err.println("Training system：" + (e3 - s3) + "(ms)");

			/** Evaluating and updating system, 系统动态更新与评估 */
			long s4 = System.currentTimeMillis();
			c3s.evaluateS(test_vec);
			long e4 = System.currentTimeMillis();
			System.err.println("Evaluating system：" + (e4 - s4) + "(ms)");
		} // end_of_for_20_loops
	}// end_of_main
}
