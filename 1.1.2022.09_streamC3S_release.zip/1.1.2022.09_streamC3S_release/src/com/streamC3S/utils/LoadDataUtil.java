package com.streamC3S.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;

/**
 * @author YunlongMi
 * @version V1.1
 * @date Oct. 6, 2019
 *
 */
public class LoadDataUtil {

	/**
	 * @param train_path
	 * @return dataset with matrix form
	 * @throws IOException
	 * @details X:data information, Y:label information, classNumber: the number of
	 *          each class, <key, value>= <class, classNumber>.
	 */
	public static Vector<Object> loadData(String train_path) throws IOException {
		BufferedReader bufr = new BufferedReader(new FileReader(train_path));
		HashMap<Integer, Integer> calssNumber = new HashMap<Integer, Integer>();
		List<String> list = new ArrayList<String>();
		String line = null;
		while ((line = bufr.readLine()) != null) {
			list.add(line);
		}
		bufr.close();

		double[][] X;// save samples
		int[] Y;// save label information
		/** (1) 有行号与列名: 需去掉行与列，将由训练系统自己动生成行号 */
		if (list.get(0).split(",")[0].toLowerCase().equals("obj")) {
			list.remove(0);// 去掉行标志
			X = new double[list.size()][list.get(0).split(",").length - 2];// 标志行与列均不存储
			Y = new int[list.size()];
			for (int i = 0; i < list.size(); ++i) {// 行
				String[] lineArray = list.get(i).split(",");
				/** data information */
				for (int j = 1; j < lineArray.length - 1; ++j) {// 第1列开始,去掉标志列
					X[i][j - 1] = Double.parseDouble(lineArray[j]);
				} // end_of_for
				/** label information */
				Y[i] = Integer.parseInt(lineArray[lineArray.length - 1]);
				/** class space information */
				int key = Integer.parseInt(lineArray[lineArray.length - 1]);
				if (calssNumber.get(key) == null) {
					int value = 1;
					calssNumber.put(key, value);// key: class; value: classNumber
				} else {
					int value = calssNumber.get(key);
					calssNumber.replace(key, value, value + 1);
				} // end_of_if
			} // end_of_for
		} else {
			/** (2) 无行号与列名 */
			X = new double[list.size()][list.get(0).split(",").length - 1];
			Y = new int[list.size()];
			for (int i = 0; i < list.size(); ++i) {
				String[] lineArray = list.get(i).split(",");
				/** data information */
				for (int j = 0; j < lineArray.length - 1; ++j) {
					X[i][j] = Double.parseDouble(lineArray[j]);
				} // end_of_for
				/** label information */
				Y[i] = Integer.parseInt(lineArray[lineArray.length - 1]);
				/** class space information */
				int key = Integer.parseInt(lineArray[lineArray.length - 1]);
				if (calssNumber.get(key) == null) {
					int value = 1;
					calssNumber.put(key, value);// key: class; value: classNumber
				} else {
					int value = calssNumber.get(key);
					calssNumber.replace(key, value, value + 1);
				} // end_of_if
			} // end_of_for
		} // end_of_if

		list = null;// 释放内存
		Vector<Object> vec = new Vector<Object>();// return two different value using vector in java
		vec.add(X);// X:data information
		vec.add(Y);// Y:label information
		vec.add(calssNumber);// class space information. key: class, value: classNumber
		return vec;
	}// end_of_loadTrainData

	/**
	 * @param train_path
	 * @param validation_path
	 * @return dataset with matrix form.
	 * @throws IOException
	 * @details grow+validation ---> train, 会自动排序,不需要预先手工排序
	 */
	public static Vector<Object> load2Data(String train_path, String validation_path) throws IOException {
		BufferedReader bufrG = new BufferedReader(new FileReader(train_path));// 此时的train也称之为grow
		HashMap<Integer, Integer> calssNumber = new HashMap<Integer, Integer>();
		List<String> list = new ArrayList<String>();
		String lineG = null;
		while ((lineG = bufrG.readLine()) != null) {
			list.add(lineG);
		}
		BufferedReader bufrV = new BufferedReader(new FileReader(validation_path));
		String lineV = null;
		while ((lineV = bufrV.readLine()) != null) {
			if (lineV.endsWith("label")) {// 若带行号,则第一行不需加载
				continue;
			}
			list.add(lineV);
		}
		bufrG.close();
		bufrV.close();

		double[][] X_Y;
		/** (1) 有行号与列名: 需去掉行与列，将由训练系统自己动生成行号 */
		if (list.get(0).split(",")[0].toLowerCase().equals("obj")) {
			list.remove(0);// 去掉行标志
			X_Y = new double[list.size()][list.get(0).split(",").length - 1];// 标志行与列均不存储
			for (int i = 0; i < list.size(); ++i) {// 行
				String[] lineArray = list.get(i).split(",");
				for (int j = 1; j < lineArray.length; ++j) {// 第1列开始,去掉标志列
					X_Y[i][j - 1] = Double.parseDouble(lineArray[j]);
				} // end_of_for
				/** class space information */
				int key = Integer.parseInt(lineArray[lineArray.length - 1]);
				if (calssNumber.get(key) == null) {
					int value = 1;
					calssNumber.put(key, value);// key: class; value: classNumber
				} else {
					int value = calssNumber.get(key);
					calssNumber.replace(key, value, value + 1);
				} // end_of_if
			} // end_of_for
		} else {
			/** (2) 无行号与列名 */
			X_Y = new double[list.size()][list.get(0).split(",").length];
			for (int i = 0; i < list.size(); ++i) {
				String[] lineArray = list.get(i).split(",");
				for (int j = 0; j <= lineArray.length - 1; ++j) {
					X_Y[i][j] = Double.parseDouble(lineArray[j]);
				} // end_of_for
				/** class space information */
				int key = Integer.parseInt(lineArray[lineArray.length - 1]);
				if (calssNumber.get(key) == null) {
					int value = 1;
					calssNumber.put(key, value);// key: class; value: classNumber
				} else {
					int value = calssNumber.get(key);
					calssNumber.replace(key, value, value + 1);
				} // end_of_if
			} // end_of_for
		} // end_of_if

		/** 按标签信息从小至大排序 */
		Arrays.sort(X_Y, new Comparator<double[]>() {
			@Override
			public int compare(double[] o1, double[] o2) {
				if (o1[X_Y[0].length - 1] < o2[X_Y[0].length - 1]) {
					return -1;
				} else if (o1[X_Y[0].length - 1] > o2[X_Y[0].length - 1]) {
					return 1;
				} else {
					return 0;
				} // end_of_if
			}// end_of_compare
		});// end_of_Arrays.sort

		/** data information */
		double[][] X = new double[X_Y.length][X_Y[0].length - 1];
		int[] Y = new int[list.size()];
		for (int row = 0; row < X_Y.length; ++row) {
			for (int col = 0; col < X_Y[0].length - 1; ++col) {
				X[row][col] = X_Y[row][col];
			}
			/** label information */
			Y[row] = (int) (X_Y[row][X_Y[0].length - 1]);
		} // end_of_for

		list = null;// 释放内存
		Vector<Object> vec = new Vector<Object>();// return two different value using vector in java
		vec.add(X);// data information
		vec.add(Y);// label information
		vec.add(calssNumber);// class space information. key: class, value: classNumber
		return vec;
	}// end_of_load2Data

}
