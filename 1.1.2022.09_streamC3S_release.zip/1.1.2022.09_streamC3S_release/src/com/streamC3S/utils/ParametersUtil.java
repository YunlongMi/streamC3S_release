package com.streamC3S.utils;

/**
 * @ClassName: PropertiesUtil
 * @Description:Set some related parameters with respect to streamC3S or streamC3S_E.
 * @author Yunlong Mi
 * @date Sep. 30, 2019
 * @since jdk1.8
 */
public class ParametersUtil {
	/** The path for data, indexNum will be replaced by the Numbers in RunMethod.java */
	 public static String train_path = "./data/TrafficStream1_initialData[indexNum].csv";
	 public static String test_path = "./data/TrafficStream1_streamData[indexNum].csv";
		
	/**
	* 0:static learning; this function is simple implementation in C3S. <br/>
	* 1:partially labeled data stream; note that, this function will be developed in the next version. <br/>
	* 2:labeled data stream, this function is for streamC3S or streamC3S_E. <br/>
	*/
	public static int U = 2;
	/** U=2, streamC3S or streamC3S_E: error corrects rate for concept drift detection. */
	public static String methodType = "streamC3S_E";
	/** Show the results by bachSize or overall accuracies.*/
	public static String showResult="overall";
	
	/** Three required parameters */
	/** Lambda(i): The $\theta$ value */
	public static int thetaT = 8;// Start: Theta  
	public static int thetaE = 8;// End: Theta
	/** MaxSize: The size of concept spaces for each class. */
	public static int conceptSZ =300;
	/** Chunk size: The size of each data chunk. */
	public static int C =100;

	/** Four optional parameters */
	/** Alpha: The concept similarity threshold. */
	public static double distF = 0.6;
	/** Epsilon: The range of the local $\alpha$-concept neighborhood. default radius=5. */
	public static int radius = 5;
	/** Delta_{d}: For U=2 and streamC3S_E, when errorCorrect < conceptDriftTheta, concept drift occurs. */
	public static double conceptDriftTheta=-0.2;//[-1,0], default conceptDriftTheta=-0.15.
	/** Delta_{w}: For U=2 and streamC3S_E, when errorCorrect > conceptWarningTheta, concept warning occurs. */
	public static double conceptWarningTheta =-0.2;//[-1,1], selected from [-0.05,0,0.05]
}
