package com.streamC3S.utils;

/**
 * @ClassName: MaxUtil
 * @Description:获取最大值下标
 * @author Dr. Yunlong Mi
 * @date Oct. 8, 2019
 * @version
 * @since jdk1.8
 */
public class MaxUtil {

	public static int getMFloatIndex(float[] arr) {
		int maxIndex = 0; // 获取到的最大值的角标
		for (int index = 0; index < arr.length; ++index) {
			if (arr[index] > arr[maxIndex]) {
				maxIndex = index;
			}
		}
		return maxIndex;
	}

	public static int getMDoubleIndex(double[] arr) {
		int maxIndex = 0; // 获取到的最大值的角标
		for (int index = 0; index < arr.length; ++index) {
			if (arr[index] > arr[maxIndex]) {
				maxIndex = index;
			}
		}
		return maxIndex;
	}

}
