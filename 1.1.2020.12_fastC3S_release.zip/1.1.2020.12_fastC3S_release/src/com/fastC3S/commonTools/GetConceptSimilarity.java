package com.fastC3S.commonTools;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.Map.Entry;

/**
 * @author YunlongMi
 * @date Jul. 7, 2020
 * @version V1.1
 * @since jdk1.8
 */
public class GetConceptSimilarity {
	/**
	 * @param conceptPoolList
	 * @param ins
	 * @param type
	 * @details 计算相似度最大值
	 */
	public Vector<Object> computeSimiarityWeithts(List<Map<double[], Set<Integer>>> conceptPoolList, double[] ins,
			int type) {
		Vector<Object> vec = new Vector<Object>();
		double maxTheta = Integer.MIN_VALUE;
		double[] intent = null;
		Map<double[], Set<Integer>> mapSet = conceptPoolList.get(type);// 根据类别获取对应的概念空间
		for (Entry<double[], Set<Integer>> entry : mapSet.entrySet()) {
			double[] attributeSet = entry.getKey(); // gets intent
			double theta = 1 - getSimilarity(ins, attributeSet); // computes concept similarity
			if (theta >= maxTheta) {
				maxTheta = theta;
				intent = entry.getKey();
			} // end_of_if
		} // end_of_for
		vec.add(maxTheta);// add max similarity
		vec.add(intent);// add the intent of concept with respect to max similarity
		return vec;
	}

	/**
	 * @param ins
	 * @param attributeSet
	 * @return 使用2范数，即欧式距离
	 */
	private static double getSimilarity(double[] ins, double[] attributeSet) {
		double result = 0.0;
		for (int i = 0; i < attributeSet.length; ++i) {
			result += Math.pow(ins[i] - attributeSet[i], 2);
		} // end_of_for
		return Math.sqrt(result);
	}// end_of_getSimilarity

}
