package com.fastC3S.commonTools;

import java.util.Set;
import java.util.Vector;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.RecursiveTask;
import com.fastC3S.utils.MaxUtil;

/**
 * @className ConcurrentComputeSimilarityByIns
 * @author Dr. YunlongMi
 * @details Concurrent Compute Similarity By Instances
 * @date Oct. 10, 2020
 * @version V1.1
 * @since jdk1.8
 */
public class ConComSimilarityByInsE extends RecursiveTask<Vector<Object>> {
	private static final long serialVersionUID = -8563054757788675804L;
	private static final int MAX = 10;
	private int beginNum, endNum;
	private ArrayList<Map<double[], Set<Integer>>> tConceptPoolList, conceptSTM;
	private double[][] bach_X;
	private int[] bach_Y;
	private int correct = 0;
	private int rowStart;
	private boolean errorRateFlag;

	public ConComSimilarityByInsE(ArrayList<Map<double[], Set<Integer>>> tConceptPoolList,
			ArrayList<Map<double[], Set<Integer>>> conceptSTM, boolean errorRateFlag, double[][] bach_X, int[] bach_Y,
			int beginNum, int endNum, int rowStart) {
		this.tConceptPoolList = tConceptPoolList;// concept pools
		this.conceptSTM = conceptSTM;
		this.errorRateFlag = errorRateFlag;
		this.bach_X = bach_X;// new coming instances
		this.bach_Y = bach_Y;// label information
		this.beginNum = beginNum;
		this.endNum = endNum;
		this.rowStart = rowStart;
	}

	@SuppressWarnings("unchecked")
	@Override
	protected Vector<Object> compute() {
		if ((endNum - beginNum) <= MAX) {
			GetConceptSimilarity gcs = new GetConceptSimilarity();
			Vector<Object> tempVec = new Vector<Object>();
			double[] ctSimilaritytWeights = new double[tConceptPoolList.size()];
			double[] ctSimilaritytWeightsSTM = new double[tConceptPoolList.size()];
			double[][] ctIntents = new double[tConceptPoolList.size()][];
			List<double[]> errorIntentList = new ArrayList<double[]>();
			List<HashMap<Integer, double[]>> instanceList = new ArrayList<HashMap<Integer, double[]>>();// <NO,attribute>
			for (int i = 0; i < tConceptPoolList.size(); ++i) {// initial instanceList
				instanceList.add(new HashMap<Integer, double[]>());// instances-<No,attribute>
			} // end_of_for

			for (int index = beginNum; index < endNum; ++index) {
				/** Compute concept similarity */
				double[] ins = bach_X[index];// intent
				for (int type = 0; type < tConceptPoolList.size(); ++type) {
					Vector<Object> vecT = gcs.computeSimiarityWeithts(tConceptPoolList, ins, type);
					Vector<Object> vecSTM = gcs.computeSimiarityWeithts(conceptSTM, ins, type);
					ctSimilaritytWeights[type] = (double) vecT.get(0);// get similarity
					ctSimilaritytWeightsSTM[type] = (double) vecSTM.get(0);// get similarity
					ctIntents[type] = (double[]) vecT.get(1);// get intent for different concepts
				} // end_of_for

				/**
				 * When a concept drift occurs, a conceptSTM will be incorporated into the
				 * system with average value.
				 */
				if (errorRateFlag) {
					for (int type = 0; type < tConceptPoolList.size(); ++type) {
						ctSimilaritytWeights[type] = (ctSimilaritytWeights[type] + ctSimilaritytWeightsSTM[type]) / 2;
					} // end_of_for
				} // end_of_if
				/**
				 * Get the numbers of correct prediction and instance list by label information.
				 */
				int pLabel = MaxUtil.getMDoubleIndex(ctSimilaritytWeights);// get prediction value (class label).
				if (pLabel == bach_Y[index]) {
					correct++;
					instanceList.get(pLabel).put(rowStart + index, ins);// get instances by class.
				} else {
					/** It means that the concept should be removed from concept spaces. */
					errorIntentList.add(ctIntents[pLabel]);// get error concepts from existing concept space
				} // end_of_if
			} // end_of_for

			tempVec.add(correct);// add correct
			tempVec.add(errorIntentList);// add error concepts
			tempVec.add(instanceList);// add correct concepts
			return tempVec;
		} else {
			int middle = (beginNum + endNum) / 2;
			ConComSimilarityByInsE left = new ConComSimilarityByInsE(tConceptPoolList, conceptSTM, errorRateFlag,
					bach_X, bach_Y, beginNum, middle, rowStart);
			ConComSimilarityByInsE right = new ConComSimilarityByInsE(tConceptPoolList, conceptSTM, errorRateFlag,
					bach_X, bach_Y, middle, endNum, rowStart);
			left.fork();
			right.fork();
			left.join();
			right.join();

			Vector<Object> tempVec = new Vector<Object>();
			int correct = (int) left.getRawResult().get(0) + (int) right.getRawResult().get(0);// correct
			List<double[]> lErrorIntentList = (List<double[]>) left.getRawResult().get(1);
			List<double[]> rErrorIntentList = (List<double[]>) right.getRawResult().get(1);
			lErrorIntentList.addAll(rErrorIntentList);// collect error concepts
			List<HashMap<Integer, double[]>> lInstanceList = (List<HashMap<Integer, double[]>>) left.getRawResult()
					.get(2);
			List<HashMap<Integer, double[]>> rInstanceList = (List<HashMap<Integer, double[]>>) right.getRawResult()
					.get(2);
			for (int i = 0; i < tConceptPoolList.size(); ++i) {
				lInstanceList.get(i).putAll(rInstanceList.get(i));// collect correct instances.
			}

			tempVec.add(correct);// add correct
			tempVec.add(lErrorIntentList); // add error concepts
			tempVec.add(lInstanceList);// add correct concepts
			return tempVec;
		} // end_of_if
	}// end_of_compute
}// end_of_class_ConcurrentComputeSimilarityByIns
