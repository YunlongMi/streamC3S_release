package com.fastC3S.evaluateS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import com.fastC3S.commonTools.ConComSimilarityByInsE;
import com.fastC3S.commonTools.GetNewConcepts;
import com.fastC3S.commonTools.UpdateConceptSpace;
import com.fastC3S.utils.ParametersUtil;
import com.fastC3S.utils.WriteFileUtil;

/**
 * @Description: A data stream with label information with chunk size.
 * @author Dr. Yunlong
 * @date Aug. 26, 2020
 */
public class UpdateAllLabC3S_E {
	private ArrayList<Map<double[], Set<Integer>>> conceptPoolList;
	private List<double[]> errorIntentList;
	private Vector<Object> test_vec;
	private int[] train_Y;

	public UpdateAllLabC3S_E(ArrayList<Map<double[], Set<Integer>>> conceptPoolList, Vector<Object> test_vec,
			int[] train_Y) {
		this.conceptPoolList = conceptPoolList;
		this.test_vec = test_vec;
		this.train_Y = train_Y;
	}

	@SuppressWarnings("unchecked")
	public void learningC3S() throws InterruptedException, ExecutionException, ClassNotFoundException, IOException {
		/** Load information */
		UpdateConceptSpace ucs = new UpdateConceptSpace();// load updating concept space function
		GetNewConcepts gnc = new GetNewConcepts();// load the method of getting new concepts.
		int batchSize = ParametersUtil.C;// load batch size

		/** Initial varies */
		double[][] test_X = (double[][]) test_vec.get(0);// data information
		int[] test_Y = (int[]) test_vec.get(1);// label information
		HashMap<Integer, Integer> classMap = (HashMap<Integer, Integer>) test_vec.get(2);// class information
		int calssNumber = classMap.size();// class information
		int tempBatchsize = 0, epoch = 0;
		boolean errorRateFlag = false;
		float corrSum = 0, aveCorrect = 0, errorCorrect = 0;
		List<HashMap<Integer, double[]>> instanceList = new ArrayList<HashMap<Integer, double[]>>();// <NO,attribute>
		ArrayList<Map<double[], Set<Integer>>> conceptSTM = new ArrayList<Map<double[], Set<Integer>>>();
		List<Map<double[], Set<Integer>>> conceptList = new ArrayList<Map<double[], Set<Integer>>>();// <intent,extent>
		List<Map<double[], Set<Integer>>> conceptSTMList = new ArrayList<Map<double[], Set<Integer>>>();// <intent,extent>
		for (int i = 0; i < calssNumber; ++i) {// initial instanceList
			conceptSTM.add(new HashMap<double[], Set<Integer>>());// save current concepts.
			instanceList.add(new HashMap<Integer, double[]>());// instances-<No,attribute>
		} // end_of_for

		/**
		 * For a data stream: if C=1, forming a new concept and computing similarity; if
		 * C>1, forming new concepts and computing concept similarity in parallel.
		 */
		for (int rowN = 0; rowN < test_X.length; rowN++) {
			tempBatchsize++;
			instanceList.get(test_Y[rowN]).put(rowN + train_Y.length, test_X[rowN]);// gets instances by class.
			/** For a batch size, it will constructing concepts in parallel. */
			if (tempBatchsize == batchSize) {
				epoch++;// record the blocks.
				int correct = 0;
				double[][] bach_X = new double[batchSize][];// an array for batch instances.
				int[] bach_Y = new int[batchSize];// an array for batch instances.
				int rowStart = rowN + train_Y.length - batchSize + 1;// the begin number of new batch size.
				/** src=test_X, srcPos, dest=bach_X, destPos=0, length=batchSize */
				System.arraycopy(test_X, epoch * batchSize - batchSize, bach_X, 0, batchSize);// for instances
				System.arraycopy(test_Y, epoch * batchSize - batchSize, bach_Y, 0, batchSize);// for label information

				ForkJoinPool forkJoinPool = new ForkJoinPool();
				Future<Vector<Object>> future = forkJoinPool.submit(new ConComSimilarityByInsE(conceptPoolList,
						conceptSTM, errorRateFlag, bach_X, bach_Y, 0, batchSize, rowStart));
				Vector<Object> vec = future.get();
				forkJoinPool.shutdown();
				correct = (int) vec.get(0);// get correct
				errorIntentList = (List<double[]>) vec.get(1);// get error concepts

				/** Save results by different batch size. */
				corrSum += (float) correct / batchSize;
				if (ParametersUtil.showResult.equals("bachSize")) {
					String fileName = "./data/Result[bachSize]_with_label_E.txt";
					WriteFileUtil outFile = new WriteFileUtil(fileName);
					outFile.fileWriterLine((float) correct / batchSize + ",");
					System.out.println(
							"epoch--" + epoch + "--accSum--" + corrSum + "--acc--" + (float) correct / batchSize);
				} // end_of_if (ParametersUtil.showResult.equals("bachSize"))

				aveCorrect = corrSum / epoch;
				errorCorrect = (float) correct / batchSize - aveCorrect;// the error rate detection.
				// System.err.println(errorCorrect);

				/**
				 * When the error rate is less than the given value, it will revoke the correct
				 * instances; otherwise the all instances in a data chunk. Meanwhile, for the
				 * error rate is greater than the given threshold, it will revoke the
				 * conceptSTM.
				 */
				if (errorCorrect > ParametersUtil.conceptWarningTheta) {// [-1,1]
					instanceList = (List<HashMap<Integer, double[]>>) vec.get(2);// get correct instances by class.
				} // end_of_if
				if (errorCorrect < ParametersUtil.conceptDriftTheta) {// [-1,0]
					// System.err.println(errorRateFlag);
					errorRateFlag = true;
					conceptSTMList = gnc.getNewConcepts(instanceList);// get new concepts based on instances.
					for (int i = 0; i < conceptSTMList.size(); ++i) {
						if (conceptSTMList.get(i).size() != 0) {
							conceptSTM.get(i).putAll(conceptSTMList.get(i));
						} // end_of_if
					} // end_of_for
				} else {
					errorRateFlag = false;
				} // end_of_if_errorCorrect
			} // end_of_if (tempBatchsize == batchSize)

			/**
			 * Construct new concepts; and then adds new concepts into original concept
			 * pools by batchSize directly. (1) For batchSize=1, it will add new concepts
			 * into pool directly; (2) For batchSize>1, it will update the concept pool with
			 * removing errorIntentList and completing concept fusion process.
			 */
			if (tempBatchsize == batchSize) {
				conceptList = gnc.getNewConcepts(instanceList);// get new concepts.
				ucs.updateConceptList(conceptPoolList, errorIntentList, conceptList);// correctConceptList
				tempBatchsize = 0; // initial to 0.
				instanceList.clear();// clear instances.
				for (int i = 0; i < calssNumber; ++i) {// initial instanceList
					instanceList.add(new HashMap<Integer, double[]>());
				} // end_of_for
			} // end_of_if
		} // end_of_for

		/** 将其结果保存到文件中:[所有正确样本/总样本数] */
		// String fileName = "./data/Result.txt";
		// WriteFileUtil outFile = new WriteFileUtil(fileName);
		// outFile.fileWriter((float) correct / test_Y.length + ",");
		// System.out.println((float) correct / test_Y.length + ",");

		/** 将其结果保存到文件中:[所有块/总块数] */
		if (ParametersUtil.showResult.equals("overall")) {
			int chunk_num = test_Y.length / ParametersUtil.C;
			String fileName = "./data/Result[overall]_with_label_E.txt";
			WriteFileUtil outFile = new WriteFileUtil(fileName);
			outFile.fileWriter((float) corrSum / chunk_num + ",");
			System.out.println("overallAcc--" + (float) corrSum / chunk_num + "--chunkNum--" + chunk_num);
		} // end_of_if (ParametersUtil.showResult.equals("overall"))
	}
}
