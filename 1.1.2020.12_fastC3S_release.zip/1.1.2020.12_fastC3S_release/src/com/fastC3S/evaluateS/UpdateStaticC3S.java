package com.fastC3S.evaluateS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import com.fastC3S.commonTools.ConComSimilarityByClass;
import com.fastC3S.commonTools.GetConceptSimilarity;
import com.fastC3S.utils.MaxUtil;
import com.fastC3S.utils.WriteFileUtil;

/**
 * @Description: Static concept learning
 * @author Dr. Yunlong Mi
 * @date Jul. 16, 2020
 */
public class UpdateStaticC3S {
	private ArrayList<Map<double[], Set<Integer>>> conceptPoolList;
	private Vector<Object> test_vec;

	public UpdateStaticC3S(ArrayList<Map<double[], Set<Integer>>> conceptPoolList, Vector<Object> test_vec) {
		this.conceptPoolList = conceptPoolList;
		this.test_vec = test_vec;
	}

	@SuppressWarnings("unchecked")
	public void learningC3S() throws InterruptedException, ExecutionException, ClassNotFoundException, IOException {
		/** Initial varies. */
		double[][] test_X = (double[][]) test_vec.get(0);// instances information
		int[] test_Y = (int[]) test_vec.get(1);// label information
		HashMap<Integer, Integer> classMap = (HashMap<Integer, Integer>) test_vec.get(2);
		int calssNumber = classMap.size();// class information
		GetConceptSimilarity gcs = new GetConceptSimilarity();// loads concept similarity function
		double[] ctSimilaritytWeights = new double[calssNumber];// saves concept similarity
		int correctSum = 0;// saves the number of instances of the correct prediction

		/** Makes predictions. */
		for (int rowN = 0; rowN < test_X.length; rowN++) {
			/** Compute the similarity degree of each class. */
			for (int type = 0; type < calssNumber; ++type) {
				Object[] objT = conceptPoolList.get(type).entrySet().toArray();
				double[] ins = test_X[rowN];
				/**
				 * Computes concepts by concurrent methods when the size is greater than 5000;
				 * otherwise, we can compute it by serial methods.
				 */
				if (objT.length > 5000) {
					ForkJoinPool forkJoinPoolT = new ForkJoinPool();
					Future<Double> futureT = forkJoinPoolT
							.submit(new ConComSimilarityByClass(objT, ins, 0, objT.length - 1));
					ctSimilaritytWeights[type] = futureT.get();
					forkJoinPoolT.shutdown();
				} else {
					Vector<Object> vec = gcs.computeSimiarityWeithts(conceptPoolList, ins, type);
					ctSimilaritytWeights[type] = (double) vec.get(0);// Gets similarity
				} // end_of_if
			} // end_of_for

			/** Gets the numbers of correct prediction. */
			int pLabel = MaxUtil.getMDoubleIndex(ctSimilaritytWeights);// Gets prediction value (class label).
			if (pLabel == test_Y[rowN]) {
				correctSum++;
			} // end_of_if
		} // end_of_for

		/** Outputs and saves accuracy. */
		System.out.println((float) correctSum / test_Y.length + ",");
		String fileName = "./data/static_result.txt";
		WriteFileUtil outFile = new WriteFileUtil(fileName);
		outFile.fileWriter((float) correctSum / test_Y.length + ",");
	}
}
