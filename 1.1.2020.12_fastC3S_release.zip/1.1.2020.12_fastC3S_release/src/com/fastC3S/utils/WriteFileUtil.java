package com.fastC3S.utils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class WriteFileUtil {
	private String	fileName;
	BufferedWriter	out	= null;

	public WriteFileUtil(String fileNames) {
		this.fileName = fileNames;
	}

	/**
	 * @param 换行
	 */
	public void fileWriter(String content) {
		try {
			out = new BufferedWriter(new FileWriter(fileName, true));
			out.write(content+"\n");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}// end_of_fileWriter
	
	/**
	 * @param 不换行
	 */
	public void fileWriterLine(String content) {
		try {
			out = new BufferedWriter(new FileWriter(fileName, true));
			out.write(content);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}// end_of_fileWriter
}
